package com.productivity.wellbeing.service

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import com.productivity.wellbeing.data.BlockPrefs
import com.productivity.wellbeing.data.Usage

class AppBlockAccessibilityService : AccessibilityService() {
    private var lastBlockedPackage: String? = null
    private var lastActionAt = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            event?.eventType != AccessibilityEvent.TYPE_WINDOWS_CHANGED) return

        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName || pkg == "com.android.systemui") return

        val tracked = BlockPrefs.getTracked(this)
        if (pkg !in tracked) {
            lastBlockedPackage = null
            return
        }

        val limit = BlockPrefs.getLimit(this, pkg)
        if (limit <= 0) return

        val usedMs = Usage.packageUsageMs(this, pkg)
        if (usedMs >= limit * 60_000L) {
            val now = System.currentTimeMillis()
            if (lastBlockedPackage != pkg || now - lastActionAt > 1200L) {
                lastBlockedPackage = pkg
                lastActionAt = now
                performGlobalAction(GLOBAL_ACTION_HOME)
            }
        } else {
            lastBlockedPackage = null
        }
    }

    override fun onInterrupt() = Unit
}
