package com.productivity.wellbeing.data

import android.content.Context

object BlockPrefs {
    private const val PREFS = "wellbeing_blocking"
    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun getLimit(context: Context, packageName: String): Int =
        prefs(context).getInt("limit_$packageName", 0)

    fun setLimit(context: Context, packageName: String, minutes: Int) {
        prefs(context).edit().putInt("limit_$packageName", minutes.coerceAtLeast(0)).apply()
    }

    fun getTracked(context: Context): Set<String> =
        prefs(context).getStringSet("tracked_apps", emptySet())?.toSet() ?: emptySet()

    fun setTracked(context: Context, packages: Set<String>) {
        prefs(context).edit().putStringSet("tracked_apps", packages.toSet()).apply()
    }
}
