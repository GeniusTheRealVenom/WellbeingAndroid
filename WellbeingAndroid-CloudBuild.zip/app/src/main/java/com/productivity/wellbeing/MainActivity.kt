package com.productivity.wellbeing

import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.content.pm.PackageManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.productivity.wellbeing.data.BlockPrefs
import com.productivity.wellbeing.data.Usage
import java.util.concurrent.TimeUnit

data class LaunchableApp(val label: String, val packageName: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { WellbeingScreen() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WellbeingScreen() {
    val context = LocalContext.current
    var refresh by remember { mutableIntStateOf(0) }
    var hasUsage by remember { mutableStateOf(Usage.hasPermission(context)) }
    var tracked by remember { mutableStateOf(BlockPrefs.getTracked(context)) }
    var totalMs by remember { mutableLongStateOf(0L) }

    LaunchedEffect(refresh) {
        hasUsage = Usage.hasPermission(context)
        tracked = BlockPrefs.getTracked(context)
        if (hasUsage) totalMs = Usage.totalTodayMs(context)
    }

    val apps = remember(refresh) { loadApps(context) }
    val accessibilityEnabled = remember(refresh) { isAccessibilityEnabled(context) }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = androidx.compose.ui.graphics.Color(0xFF2DD4BF),
        secondary = androidx.compose.ui.graphics.Color(0xFF818CF8),
        background = androidx.compose.ui.graphics.Color(0xFF0F172A),
        surface = androidx.compose.ui.graphics.Color(0xFF1E293B)
    )) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Wellbeing", fontWeight = FontWeight.Bold) },
                    actions = { IconButton(onClick = { refresh++ }) { Icon(Icons.Default.Refresh, "Refresh") } },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
                )
            },
            containerColor = MaterialTheme.colorScheme.background
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                        Column(Modifier.padding(20.dp)) {
                            Text("Today's screen time", style = MaterialTheme.typography.titleMedium)
                            Spacer(Modifier.height(8.dp))
                            Text(if (hasUsage) formatTime(totalMs) else "Permission required",
                                style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                            Text("Usage totals are provided by Android and may update with a short delay.",
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("Required permissions", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                            Text("Usage Access: ${if (hasUsage) "Enabled" else "Not enabled"}")
                            Button(onClick = { context.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }, modifier = Modifier.fillMaxWidth()) {
                                Text("Open Usage Access settings")
                            }
                            Divider()
                            Text("Accessibility blocker: ${if (accessibilityEnabled) "Enabled" else "Not enabled"}")
                            Button(onClick = { context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }, modifier = Modifier.fillMaxWidth()) {
                                Text("Enable app blocker")
                            }
                            Text("In Android Accessibility settings, select Wellbeing and turn on its service.",
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
                item {
                    Text("App limits", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("Choose apps and set a daily limit. Set the limit to 0 to disable blocking.",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (!hasUsage) {
                    item { Text("Enable Usage Access above to load app usage and configure reliable daily limits.") }
                } else {
                    items(apps, key = { it.packageName }) { app ->
                        val selected = app.packageName in tracked
                        var limit by remember(app.packageName, refresh) {
                            mutableIntStateOf(BlockPrefs.getLimit(context, app.packageName).takeIf { it > 0 } ?: 60)
                        }
                        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                            Column(Modifier.padding(14.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(app.label, fontWeight = FontWeight.SemiBold)
                                        Text(app.packageName, style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    Switch(
                                        checked = selected,
                                        onCheckedChange = { checked ->
                                            tracked = if (checked) tracked + app.packageName else tracked - app.packageName
                                            BlockPrefs.setTracked(context, tracked)
                                            if (checked && BlockPrefs.getLimit(context, app.packageName) == 0)
                                                BlockPrefs.setLimit(context, app.packageName, limit)
                                            refresh++
                                        }
                                    )
                                }
                                if (selected) {
                                    Spacer(Modifier.height(8.dp))
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("Daily limit", modifier = Modifier.weight(1f))
                                        Text("$limit min", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                                    }
                                    Slider(
                                        value = limit.toFloat(),
                                        onValueChange = { limit = it.toInt().coerceIn(5, 600) },
                                        valueRange = 5f..600f,
                                        steps = 118
                                    )
                                    TextButton(onClick = {
                                        BlockPrefs.setLimit(context, app.packageName, limit)
                                        refresh++
                                    }) { Text("Save limit") }
                                }
                            }
                        }
                    }
                }
                item {
                    Text("How blocking works", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("When a selected app reaches its daily limit, the accessibility service sends the device to the Home screen whenever that app is opened. Blocking depends on Android permissions and can be disabled in system settings.",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

private fun loadApps(context: Context): List<LaunchableApp> {
    val pm = context.packageManager
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
        .map { LaunchableApp(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
        .filter { it.packageName != context.packageName }
        .distinctBy { it.packageName }
        .sortedBy { it.label.lowercase() }
}

private fun isAccessibilityEnabled(context: Context): Boolean {
    val enabled = Settings.Secure.getString(context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
    return enabled.contains("${context.packageName}/${com.productivity.wellbeing.service.AppBlockAccessibilityService::class.java.name}", ignoreCase = true)
}

private fun formatTime(ms: Long): String {
    val mins = TimeUnit.MILLISECONDS.toMinutes(ms)
    val h = mins / 60
    val m = mins % 60
    return if (h > 0) "${h}h ${m}m" else "${m}m"
}
