# Wellbeing Android project

## Build an APK
1. Install Android Studio (latest stable) and Android SDK Platform 35.
2. Open this folder in Android Studio.
3. Allow Gradle sync to finish.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio creates the APK at `app/build/outputs/apk/debug/app-debug.apk`.

## Enable app blocking
1. Open Wellbeing.
2. Tap **Open Usage Access settings**, find Wellbeing, and allow usage access.
3. Return to Wellbeing and tap **Enable app blocker**.
4. In Accessibility settings, open Wellbeing and enable its service.
5. Select apps, switch them on, adjust their daily limits, and tap **Save limit**.

## Important limitations
- Android requires the user to explicitly enable Usage Access and the Accessibility service.
- Blocking is enforced by returning the device to the Home screen when a limited app is opened after its daily limit is reached. It is not an OS-level uninstallable kiosk lock and can be disabled in Android settings.
- Usage statistics are estimates supplied by Android and can be delayed or aggregated differently by device manufacturers.
- This starter project uses local SharedPreferences; it does not upload usage data.
- Test on your own device before relying on it. Different Android manufacturers may apply additional background restrictions.

## Build in the cloud using only your phone (GitHub Actions)
1. Create a free GitHub account if you do not already have one.
2. In your mobile browser, create a **public or private** new repository named `WellbeingAndroid`.
3. Extract this ZIP on your phone.
4. In the repository, use **Add file > Upload files** and upload the extracted project contents, including the hidden `.github/workflows/android-apk.yml` file. If your phone's file picker cannot select folders or hidden files, use GitHub's desktop-site mode or the GitHub mobile app/browser with a file manager that can show hidden files.
5. Commit the files to the `main` branch.
6. Open the repository's **Actions** tab, choose **Build Wellbeing APK**, and tap **Run workflow** if it did not start automatically.
7. When the workflow completes, open its run, scroll to **Artifacts**, and download `Wellbeing-debug-apk`. Extract it and install `app-debug.apk`.

The GitHub-hosted runner compiles the APK; no PC or Android Studio is required. GitHub may require confirming that Actions are enabled for the repository. The first build can take several minutes.
