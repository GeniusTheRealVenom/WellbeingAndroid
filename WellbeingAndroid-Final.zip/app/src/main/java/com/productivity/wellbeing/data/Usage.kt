package com.productivity.wellbeing.data

import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.Process
import java.util.Calendar

data class AppUsage(val packageName: String, val timeMs: Long)

object Usage {
    fun hasPermission(context: Context): Boolean {
        val ops = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        return ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.packageName) == AppOpsManager.MODE_ALLOWED
    }

    fun dayBounds(daysAgo: Int = 0): Pair<Long, Long> {
        val start = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            add(Calendar.DAY_OF_YEAR, -daysAgo)
        }.timeInMillis
        val end = if (daysAgo == 0) System.currentTimeMillis() else start + 24L * 60L * 60L * 1000L
        return start to end
    }

    fun todayMillis(): Pair<Long, Long> = dayBounds(0)

    private fun query(context: Context, start: Long, end: Long) =
        (context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager)
            .queryUsageStats(UsageStatsManager.INTERVAL_DAILY, start, end).orEmpty()

    fun packageUsageMs(context: Context, packageName: String): Long {
        val (start, end) = todayMillis()
        return query(context, start, end).filter { it.packageName == packageName }.sumOf { it.totalTimeInForeground }
    }

    fun todayByApp(context: Context): List<AppUsage> {
        val (start, end) = todayMillis()
        return query(context, start, end)
            .groupBy { it.packageName }
            .map { (pkg, stats) -> AppUsage(pkg, stats.sumOf { it.totalTimeInForeground }) }
            .filter { it.timeMs > 0L }
    }

    fun lastSevenDays(context: Context): List<Long> =
        (6 downTo 0).map { daysAgo ->
            val (start, end) = dayBounds(daysAgo)
            query(context, start, end).sumOf { it.totalTimeInForeground }
        }

    fun totalTodayMs(context: Context): Long = todayByApp(context).sumOf { it.timeMs }
}
